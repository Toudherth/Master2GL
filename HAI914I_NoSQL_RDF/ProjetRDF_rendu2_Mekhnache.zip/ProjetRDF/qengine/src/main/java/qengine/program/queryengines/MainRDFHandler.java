package qengine.program.queryengines;

import org.eclipse.rdf4j.model.Statement;
import org.eclipse.rdf4j.rio.helpers.AbstractRDFHandler;
import qengine.program.dectionnaire.Dictionary;
import qengine.program.index.Index;

public class MainRDFHandler extends AbstractRDFHandler {

        @Override
        public void handleStatement(Statement st) {

            // Updating Dictionnary
            Dictionary d = Dictionary.getInstance();
            d.add(st.getSubject().toString());
            d.add(st.getPredicate().toString());
            d.add(st.getObject().toString());

            // Indexing the statement
            Index i = Index.getInstance();
            i.indexStatement(st);
        }

}
