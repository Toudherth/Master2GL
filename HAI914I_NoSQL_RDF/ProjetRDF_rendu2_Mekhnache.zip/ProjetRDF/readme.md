# Information rendu

Comment executer ?
cd qengine
java -jar target/qengine-0.0.1-SNAPSHOT-jar-with-dependencies.jar


les options: Jena, Shuffle, Warm, data, queries, output fonctionnent


Vous trouverez dans le fichier "resultQueries.csv" le resultat des requettes


On vous affiche dans le terminal certaines informations sur les temps d'executions.
Nous l'importons aussi dans un fichier csv si l'option output est selectionée.



On peut activer jena avec l'option -jena, dans ce cas nous afficherons seulement les requettes qui rendent des resultats differents de notre systeme